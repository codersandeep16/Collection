package LinkedList;

import java.util.Iterator;
import java.util.LinkedList;

public class Task2 {
	public static void main(String[] args) {
		LinkedList<String> l = new LinkedList<String>();
		l.add("Ronaldo");
		l.add("Messi");
		l.add("Neymar");
		l.add("Mbappe");
		l.add("Giggs");
		l.add("Rooney");
		l.add("Chetri");
		l.add("Persie");
		l.add("Zlatan");
		System.out.println("The LinkedList elements are: ");
		for (Iterator i = l.iterator(); i.hasNext();) {
			System.out.println(i.next());
		}

	}
}
