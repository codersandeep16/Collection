package LinkedList;

import java.util.LinkedList;

public class Task3_2 {
	public static void main(String[] args) {
		LinkedList<String> footballers = new LinkedList<String>();
		footballers.add("Ronaldo");
		footballers.add("Messi");
		footballers.add("Neymar");
		footballers.add("Mbappe");
		footballers.add("Giggs");
		footballers.add("Rooney");
		footballers.add("Chetri");
		footballers.add("Persie");
		footballers.add("Zlatan");
		System.out.println(footballers);

		footballers.remove(3);
		footballers.remove("Rooney");

		System.out.println("Final LinkedList:" + footballers);

	}

}
